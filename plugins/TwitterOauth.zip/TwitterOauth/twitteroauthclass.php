<?php
/**
 * Plugin Name: Twitter Oauth
 * Plugin URI:  http://themeforest.net/user/phpface
 * Description: Twitter Oauth Class
 * Version:     1.0
 * Author:      Toan Nguyen
 * Author URI:  http://themeforest.net/user/phpface
 * License:     GPL-2.0+
 * License URI: http://www.gnu.org/licenses/gpl-2.0.txt
 */
if( !defined('ABSPATH') ) exit;
if( !class_exists('TwitterOAuth') ){
	require 'twitteroauth.php';
}